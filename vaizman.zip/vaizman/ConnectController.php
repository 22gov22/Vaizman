<?php

require_once('apiCall.php');
$apiCall = new ApiCall();

//  Create item
if(isset($_POST['create']) && !empty($_POST['create']) && $_POST['create'] == 'create'){

    $error  = false;

    if(!empty($_POST['id'])){
        if ( filter_var($_POST['id'], FILTER_VALIDATE_INT) !== false) {
            $itemId = $_POST['id'];
        } else {
            $error  = "ID is not an integer";
        }
    }else{
        $error  .= 'ID is required Field ! ' ;
    }

    if(!empty($_POST['content'])){
        $content = filter_var( $_POST['content'] ,FILTER_SANITIZE_SPECIAL_CHARS);        
    }else{
        $error  .= 'ID is required Field ! ' ;
    }

    if(!empty($_POST['classes'])){
        $c_name = filter_var( $_POST['classes'] ,FILTER_SANITIZE_SPECIAL_CHARS);        
    }else{
        $error  .= 'Classes is required Field ! ' ;
    }

    if(!empty($_POST['checkbox'])){
        $checkbox = filter_var( $_POST['checkbox'] , FILTER_VALIDATE_BOOLEAN );
    }else{
        $error  .= 'Checkbox is required Field ! ' ;
    }

    if($error){
        handle_response('error','Error Validate Side !', $error);
    }

    $apiCall->createItem($itemId,$content,$c_name,$checkbox);
}
// Update Item
if(isset($_POST['updateItem']) && !empty($_POST['updateItem']) && $_POST['updateItem'] == 'update'){

    $error  = false;

    if(!empty($_POST['id'])){
        if ( filter_var($_POST['id'], FILTER_VALIDATE_INT) !== false) {
            $itemId = $_POST['id'];
        } else {
            $error  = "ID is not an integer";
        }
    }else{
        $error  .= 'ID is required Field ! ' ;
    }

    if(!empty($_POST['content'])){
        $content = filter_var( $_POST['content'] ,FILTER_SANITIZE_SPECIAL_CHARS);        
    }else{
        $error  .= 'ID is required Field ! ' ;
    }

    if(!empty($_POST['classes'])){
        $c_name = filter_var( $_POST['classes'] ,FILTER_SANITIZE_SPECIAL_CHARS);        
    }else{
        $error  .= 'Classes is required Field ! ' ;
    }

    if(!empty($_POST['checkbox'])){
        $checkbox = filter_var( $_POST['checkbox'] , FILTER_VALIDATE_BOOLEAN );
    }else{
        $error  .= 'Checkbox is required Field ! ' ;
    }

    if($error){
        handle_response('error','Error Validate Side !', $error);
    }

    $apiCall->updateItem($itemId,$content,$c_name,$checkbox);
}
// Delete Item
if(isset($_POST['deleteItem']) && !empty($_POST['deleteItem']) && $_POST['deleteItem'] == 'delete'){
    $error  = false;

    if(!empty($_POST['id'])){
        if ( filter_var($_POST['id'], FILTER_VALIDATE_INT) !== false) {
            $id = $_POST['id'];
        } else {
            $error  = "ID is not an integer";
        }
    }else{
        $error  .= 'ID is required Field ! ' ;
    }
    if($error){
        handle_response('error','Error Validate Side !', $error);
    }

    $apiCall->deleteItem($id);
}
// Get item by id 
if(isset($_POST['findItem']) && !empty($_POST['findItem']) && $_POST['findItem'] == 'find'){
    $error  = false;

    if(!empty($_POST['id'])){
        if ( filter_var($_POST['id'], FILTER_VALIDATE_INT) !== false) {
            $id = $_POST['id'];
        } else {
            $error  = "ID is not an integer";
        }
    }else{
        $error  .= 'ID is required Field ! ' ;
    }
    if($error){
        handle_response('error','Error Validate Side !', $error);
    }

    $apiCall->getItem($id);
}
//  Get Items 
if(isset($_POST['getAll']) && !empty($_POST['getAll']) && $_POST['getAll'] == 'get'){

    $apiCall->getItems();
}

// Function Response REST API 
function handle_response($status,$msg,$data){
    $d =  json_encode(['status' => $status,'msg' => $msg,'data' => $data]);
    echo $d;
    exit();
}
?>
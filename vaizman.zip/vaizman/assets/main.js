$( document ).ready(function() {
    /* 
       Author Serebrinsky Michael 
       Email : Gov22gov@gmail.com
    */
   
    //  Array For local storage items 
    const todoItems = [];
    
    function addItemApiCall(id,content,classes,checkbox){
        let form = new FormData();
            form.append("create", "create" );
            form.append("id", id);
            form.append("content", content );
            form.append("classes", classes );
            form.append("checkbox", checkbox );
        
        let settings = {
          "url": "http://localhost/vaizman/ConnectController.php",
          "method": "POST",
          "timeout": 0,
          "processData": false,
          "mimeType": "multipart/form-data",
          "contentType": false,
          "data": form
        };
        
        $.ajax(settings).done(function (response) {
          console.log(response);
        });
    }

    function updateApiCall(id,content,classes,checkbox){
        let form = new FormData();
        form.append("updateItem", "update" );
        form.append("id", id );
        form.append("content", content );
        form.append("classes", classes );
        form.append("checkbox", checkbox );

        let settings = {
            "url": "http://localhost/vaizman/ConnectController.php",
            "method": "POST",
            "timeout": 0,
            "processData": false,
            "mimeType": "multipart/form-data",
            "contentType": false,
            "data": form
        };

        $.ajax(settings).done(function (response) {
            console.log(response);
        });
    }

    //  Get items from local storage ( if exist )
    function getItems(){
        let items       = localStorage.getItem('todoItems');
            items       = JSON.parse(items);

        if(items){
            for (i = 0; i < items.length; ++i) {
               
                let deleted = items[i].className.includes("deleted");                
                    deleted = (deleted) ? '<a href="javascript:void(0);" class="float-right return-todo-item">Return</a>' :' <a href="javascript:void(0);" class="float-right remove-todo-item">Delete</a>';

                let checked = (items[i].btnCheck ) ? 'checked' :'';
                $('.todo-list').append('<div data-id="'+items[i].id+'" class="'+items[i].className+'"><div class="checker"><span class=""><input type="checkbox" '+checked+'></span></div> <span title="Edit" class="edit-item" >' + items[i].text + '</span> '+deleted+'</div>');
            }
        }
    }
    // Run function on load
    getItems();
    
    //  Set items to local storage
    function setItems(){
        localStorage.removeItem("todoItems");
        $( ".todo-item" ).each(function( index ) {

            let btnCheck = false;
            if($(this).find('input').is(':checked')) {
                btn = true;
            }

            let idNumber    = index+1,
                className   = $(this).attr('class'),
                text        = $(this).find('.edit-item').text();

            todoItems.push({
                    id         : idNumber,
                    text       : text,
                    className  : className,
                    btnCheck   : btnCheck
                }
            );
        });
        localStorage.setItem('todoItems', JSON.stringify(todoItems));
    }
    
    //  Update items in local storage
    function saveItems(id,classes,content,btnStats){
        updateApiCall(id,content,classes,btnStats)
        let items       = localStorage.getItem('todoItems');
            items       = JSON.parse(items);
            for (i = 0; i < items.length; ++i) {
                if(items[i].id == id ){
                    items[i].className = classes,
                    items[i].text      = content,
                    items[i].btnCheck  = btnStats                    
                }
            }
        localStorage.setItem('todoItems', JSON.stringify(items));
    }
    
    //  To Do Functionality 
    let todo = function() { 

        // Change status to item
        $('.todo-list .todo-item input').click(function() {
            
            let btn = false;
            if($(this).is(':checked')) {
                $(this).parent().parent().parent().toggleClass('complete');
                btn = true;
            } else {
                $(this).parent().parent().parent().toggleClass('complete');
            }
            let value        = $(this).parent().parent().parent().find('.edit-item').text(),
                elementId    = $(this).parent().parent().parent().attr('data-id'),
                checkdButton = btn,
                className    = $(this).parent().parent().parent().attr('class'); 
            saveItems(elementId,className,value,checkdButton);
        });
        
        // View taskts by type
        $('.todo-nav .all-task').click(function() {
            $('.todo-list').removeClass('only-active');
            $('.todo-list').removeClass('only-complete');
            $('.todo-list').removeClass('deleted-only');
            $('.todo-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        // View taskts by type
        $('.todo-nav .active-task').click(function() {
            $('.todo-list').removeClass('only-complete');
            $('.todo-list').removeClass('deleted-only');
            $('.todo-list').addClass('only-active');
            $('.todo-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        // View taskts by type
        $('.todo-nav .completed-task').click(function() {
            $('.todo-list').removeClass('only-active');
            $('.todo-list').removeClass('deleted-only');
            $('.todo-list').addClass('only-complete');
            $('.todo-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        // View taskts by type
        $('.todo-nav .deleted-task').click(function() {
            $('.todo-list').removeClass('only-active');
            $('.todo-list').removeClass('only-complete');
            $('.todo-list').addClass('deleted-only');
            $('.todo-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $('#uniform-all-complete input').click(function() {
            if($(this).is(':checked')) {
                $('.todo-item .checker span:not(.checked) input').click();
            } else {
                $('.todo-item .checker span.checked input').click();
            }
        });
        
        //  Delete/Return items functionality
        $(document).on('click','.remove-todo-item',function() {

            $(this).parent().addClass('deleted');
            $(this).text('Return');
            $(this).removeClass('remove-todo-item');
            $(this).addClass('return-todo-item');

            let value        = $(this).parent().find('.edit-item').text(),
                elementId    = $(this).parent().attr('data-id'),
                checkdButton = true,
                className    = $(this).parent().attr('class'); 
    
            saveItems(elementId,className,value,checkdButton);
            
        }).on('click','.return-todo-item',function() {    
            
            $(this).parent().removeClass('deleted');       
            $(this).text('Delete');
            $(this).removeClass('return-todo-item');
            $(this).addClass('remove-todo-item');
            let value        = $(this).parent().find('.edit-item').text(),
                elementId    = $(this).parent().attr('data-id'),
                checkdButton = false,
                className    = $(this).parent().attr('class'); 

            saveItems(elementId,className,value,checkdButton);
           
        })
       
    };
    
    todo();
    
    //  Add new task by press Enter*
    $(".add-task").keypress(function (e) {
      
        if ((e.which == 13)&&(!$(this).val().length == 0)) {
            let idNumber = $( ".todo-item" ).last().attr('data-id');
            if(idNumber){
                idNumber++;
            }else{
                idNumber = 1;
            }          
            $('.todo-list').append('<div data-id="'+idNumber+'" class="todo-item"><div class="checker"><span class=""><input type="checkbox"></span></div> <span title="Edit" class="edit-item" >' + $(this).val() + '</span> <a href="javascript:void(0);" class="float-right remove-todo-item">Delete</a></div>');                            
            $(this).val('');  
            // Api Save Item          
            addItemApiCall(idNumber,$(this).val(),'todo-item',false);
            setItems();
        } else if(e.which == 13) {
            alert('Please enter new task');
        }
        $(document).on('.todo-list .todo-item.added input').click(function() {
            if($(this).is(':checked')) {
                $(this).parent().parent().parent().toggleClass('complete');
            } else {
                $(this).parent().parent().parent().toggleClass('complete');
            }
          
        });
        $('.todo-list .todo-item.added .remove-todo-item').click(function() {
            $(this).parent().remove();
        });
    });

    //  Update Item Content ( Save Cancel )
    $(document).on('click','#save-edit-text',function(){
        $(this).parent().removeClass('edit-active');
        let newValue  = $('#edit-value').val(),
            elementId = $(this).parent().attr('data-id'),
            className = $(this).parent().attr('class');   
        $(this).parent().find('.edit-item').text(newValue).show();
        $('#edit-value, #save-edit-text, #cancel-edit-text').remove();        
        saveItems(elementId,className,newValue);
    }).on('click','#cancel-edit-text',function(){
        let oldValue  = $('#edit-value').attr('data-old');     
        $(this).parent().find('.edit-item').text(oldValue).show();
        $('#edit-value, #save-edit-text, #cancel-edit-text').remove();
        $(this).parent().removeClass('edit-active');
        
    }).on('click','.edit-item',function(){
        $('#edit-value, #save-edit-text, #cancel-edit-text').remove();
        let oldValue   = $(this).text();
        $(this).parent().addClass('edit-active');
        $(this).hide();
        $(this).parent().append("<input type='text' data-old='"+oldValue+"' value='"+oldValue+"' id='edit-value' ><span id='save-edit-text' class='btn btn-success ml-3'>Save</span><span class='btn btn-danger' id='cancel-edit-text'>Cancel</span>");
    })

});
Good day!

This work was done by Michael Serebrinsky

In front of you is a folder with all the robot for correct work, you need to place it in the Local folder www.localhost.com/vaizman

1. Еhere is an index.html file in the folder  these are the test questions.
2. Folder contains todo.html file ... These are tasks about creating a task sheet. 
   Also contains a part of the API (embedded inside) you can see the LOG that will appear when creating or declaring a task
3. Аlso there are 2 files in the folder -> apiCall.php and ConnectController.php who are responsible for API tasks.
   and require a specific environment to work.
4. Also in PHP README folder you can find everything related to API requests. Including example requests

 Michael Serebrinsky 
 PHP WEB DEVELOPER
 gov22gov@gmail.com
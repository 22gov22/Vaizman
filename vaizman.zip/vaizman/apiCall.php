<?php

//  Api class for use 
//  Example $var = new ApiCrud();

class ApiCall{

  private $servername;
  private $username;
  private $password;
  private $db;
  private $connection;

  function __construct() {
    $this->servername = "localhost";
    $this->username   = "root";
    $this->password   = "";
    $this->db         = "todo_list_db";
    $this->connection = $this->conn();
  }

  private function conn(){
    try {
      $conn = new PDO("mysql:host=$this->servername;dbname=".$this->db,$this->username, $this->password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
      echo "Connection failed: " . $e->getMessage();
      return false;
    }
    return $conn;
  }

  public function handle_response($status,$msg,$data){
      $d =  json_encode(['status' => $status,'msg' => $msg,'data' => $data]);
      echo $d;
      exit();
  }

  public function createItem($id,$content,$c_name,$checkbox){
      $sql            = "INSERT INTO items ( item_id, content, class_names, checkbox ) VALUES ( ?, ?, ?, ? )";
      $pdo_statement  = $this->connection->prepare( $sql );
      $result         = $pdo_statement->execute( 
          [ $id,  $content,  $c_name , $checkbox]
      );

      $this->handle_response(200,'Item has been created',$result);
  }

  public function updateItem($id,$content,$c_name,$checkbox){
    $sql            = "UPDATE items SET content=?, class_names=?, checkbox=?  WHERE id=? ";
    $pdo_statement  = $this->connection->prepare( $sql );
    $result         = $pdo_statement->execute( 
        [ $content,  $c_name , $checkbox,$id]
    );

    $this->handle_response(200,'Item has been updated!',$result);
  }
  
  public function getItem($id){
    $pdo_statement = $this->connection->prepare("SELECT * FROM items WHERE id=:id");
    $pdo_statement->execute(['id' => $id]); 
    $result  = $pdo_statement->fetch();
    $this->handle_response(200,'',$result );
  }

  public function getItems(){
    $pdo_statement = $this->connection->prepare("SELECT * FROM items");
    $pdo_statement->execute(); 
    $result        = $pdo_statement->fetch();
    $this->handle_response(200,'',$result);
  }

  public function deleteItem($id){
    $sql            = "DELETE FROM items WHERE id=?";
    $pdo_statement  = $this->connection->prepare($sql);
    $result         = $pdo_statement->execute([$id]);
    $this->handle_response(200,'Item has been deleted!',$result);
  }

}

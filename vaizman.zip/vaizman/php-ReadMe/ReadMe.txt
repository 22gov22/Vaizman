DB  : todo_list_db

Create TABLE :

insert sql 
CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `class_names` varchar(255) NOT NULL,
  `checkbox` tinyint(1) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



All API calls by link : http://localhost/vaizman/ConnectController.php

*********************************
Api Calls ( PHP )
Create -> 
EXAMPLE :
****************************
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/vaizman/ConnectController.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('create' => 'create','id' => '4','content' => 'Some Test','classes' => 'one ant-two','checkbox' => 'true'),
));
$response = curl_exec($curl);
curl_close($curl);
var_dump($response);
END EXAMPLE 

*****************************
Api Calls ( PHP )
Update -> 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/vaizman/ConnectController.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('updateItem' => 'update','id' => '1','content' => 'Some Test NEW!','classes' => 'one ant-two www','checkbox' => 'true'),
));

$response = curl_exec($curl);

curl_close($curl);
var_dump($response);
END EXAMPLE
*****************************

Api Calls ( PHP )
Delete  ->

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/vaizman/ConnectController.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('deleteItem' => 'delete','id' => '2'),
));

$response = curl_exec($curl);

curl_close($curl);
var_dump($response);

*****************************

Api Calls ( PHP )
Get item by id  ->
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/vaizman/ConnectController.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('findItem' => 'find','id' => '4'),
));

$response = curl_exec($curl);

curl_close($curl);
var_dump($response);

*****************************

Api Calls ( PHP )
Get items   ->

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/vaizman/ConnectController.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('getAll' => 'get'),
));

$response = curl_exec($curl);

curl_close($curl);
var_dump($response); 

*****************************

